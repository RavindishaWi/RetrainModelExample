
outfits - v1 v1
==============================

This dataset was exported via roboflow.ai on April 20, 2021 at 4:55 PM GMT

It includes 270 images.
Outfits are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


