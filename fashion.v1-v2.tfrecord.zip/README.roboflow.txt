
fashion - v1 v2
==============================

This dataset was exported via roboflow.ai on April 21, 2021 at 7:36 AM GMT

It includes 126 images.
Fashion are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


